
console.log("RavenCore main loop initiated");
document.body.innerHTML += "<p>Avatar system: Active</p><p>Command Console: Online</p>";
