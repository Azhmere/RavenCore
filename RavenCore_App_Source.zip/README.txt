
RavenCore v1.0 (Offline Installable APK Shell)

This ZIP contains the base source code for the RavenCore personal assistant app.

To build and install this as an APK:
1. Use Android Studio or APKBuilder.com
2. Add these files to your project directory
3. Sign and export the APK manually

Startup Message: "Loop online. RavenCore awakening..."
